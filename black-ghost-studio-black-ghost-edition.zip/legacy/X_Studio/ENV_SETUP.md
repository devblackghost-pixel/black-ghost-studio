# Configuration privée de X Studio

Le fichier `.env` original n’est pas publié dans la nouvelle version afin de ne pas exposer de secrets. Pour un environnement privé, créez un fichier `.env` à partir des variables suivantes :

```env
AUDD_API_KEY=
YOUTUBE_API_KEY=
DOWNLOAD_PATH=downloads
NODE_ENV=development
```

Les variables `AUDD_API_KEY` et `YOUTUBE_API_KEY` sont optionnelles pour les fonctionnalités actuellement intégrées. La recherche backend fonctionne sans clé API en utilisant la page publique de YouTube. La page Shazam nécessite une clé AudD uniquement si l’identification audio réelle est activée.

Pour utiliser `cookies.txt` avec yt-dlp, placez votre copie personnelle uniquement dans `legacy/X_Studio/cookies.txt` sur un environnement privé, puis lancez le téléchargement local avec l’option `--cookies legacy/X_Studio/cookies.txt`. Ne sauvegardez pas cette copie dans un dépôt public et ne l’incluez pas dans une image de production : elle peut contenir une session YouTube active. Le fichier `cookies.txt` présent dans cette version est seulement un placeholder vide.

Ne placez jamais de clé réelle dans le dépôt, dans une archive publique ou dans le frontend. Dans l’interface de travail, utilisez le gestionnaire sécurisé des secrets pour ajouter une variable lorsque vous en aurez une.
