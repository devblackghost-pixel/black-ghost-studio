import os
import re
import threading
import time
import json
import urllib.request
import urllib.parse
from flask import Flask, render_template, request, jsonify, send_file

app = Flask(__name__)
app.config['DOWNLOAD_FOLDER'] = os.path.join(os.getcwd(), 'downloads')
os.makedirs(app.config['DOWNLOAD_FOLDER'], exist_ok=True)

downloads = {}

def search_youtube(query, limit=15):
    try:
        encoded_query = urllib.parse.quote(query)
        url = f"https://www.youtube.com/results?search_query={encoded_query}"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        req = urllib.request.Request(url, headers=headers)
        response = urllib.request.urlopen(req, timeout=10)
        html = response.read().decode('utf-8')
        
        pattern = r'ytInitialData\s*=\s*({.*?});'
        match = re.search(pattern, html)
        if not match:
            return []
        
        data = json.loads(match.group(1))
        videos = []
        
        try:
            contents = data['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
            for content in contents:
                if 'itemSectionRenderer' in content:
                    items = content['itemSectionRenderer']['contents']
                    for item in items:
                        if 'videoRenderer' in item:
                            v = item['videoRenderer']
                            video_id = v.get('videoId', '')
                            title = v.get('title', {}).get('runs', [{}])[0].get('text', 'Sans titre')
                            channel = v.get('ownerText', {}).get('runs', [{}])[0].get('text', 'Inconnu')
                            duration = v.get('lengthText', {}).get('simpleText', '')
                            views = v.get('viewCountText', {}).get('simpleText', '')
                            thumbnails = v.get('thumbnail', {}).get('thumbnails', [{}])
                            thumb_url = thumbnails[-1].get('url', '') if thumbnails else ''
                            
                            videos.append({
                                'id': video_id,
                                'title': title,
                                'channel': channel,
                                'duration': duration,
                                'views': views,
                                'thumbnails': thumb_url,
                                'url': f"https://youtube.com/watch?v={video_id}",
                                'embed_url': f"https://www.youtube.com/embed/{video_id}"
                            })
                            if len(videos) >= limit:
                                break
                if len(videos) >= limit:
                    break
        except Exception as e:
            print(f"Erreur parsing: {e}")
        
        return videos
    except Exception as e:
        print(f"Erreur recherche: {e}")
        return []

def download_worker(task_id, url, format_type, quality):
    downloads[task_id] = {'status': 'started', 'progress': 0, 'filename': '', 'error': ''}
    try:
        video_id = url.split('v=')[-1].split('&')[0]
        if 'youtu.be' in url:
            video_id = url.split('/')[-1].split('?')[0]
        
        downloads[task_id]['progress'] = 10
        
        # Utiliser une API de remplacement
        if format_type == 'mp3':
            api_url = f"https://www.yt-download.org/api/button/mp3/{video_id}"
        else:
            api_url = f"https://www.yt-download.org/api/button/mp4/{video_id}"
        
        downloads[task_id]['status'] = 'processing'
        downloads[task_id]['progress'] = 30
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        req = urllib.request.Request(api_url, headers=headers)
        response = urllib.request.urlopen(req, timeout=120)
        
        downloads[task_id]['progress'] = 60
        
        # Tenter de lire le JSON ou le binaire
        content = response.read()
        try:
            data = json.loads(content.decode('utf-8'))
            file_url = data.get('url') or data.get('download_url') or data.get('link')
        except:
            # Si ce n'est pas du JSON, on utilise directement le contenu
            ext = 'mp3' if format_type == 'mp3' else 'mp4'
            filename = f"{video_id}.{ext}"
            filepath = os.path.join(app.config['DOWNLOAD_FOLDER'], filename)
            with open(filepath, 'wb') as f:
                f.write(content)
            downloads[task_id]['filename'] = filename
            downloads[task_id]['status'] = 'completed'
            downloads[task_id]['progress'] = 100
            return
        
        if file_url:
            downloads[task_id]['progress'] = 70
            file_req = urllib.request.Request(file_url, headers=headers)
            file_response = urllib.request.urlopen(file_req, timeout=120)
            
            ext = 'mp3' if format_type == 'mp3' else 'mp4'
            filename = f"{video_id}.{ext}"
            filepath = os.path.join(app.config['DOWNLOAD_FOLDER'], filename)
            
            with open(filepath, 'wb') as f:
                f.write(file_response.read())
            
            downloads[task_id]['filename'] = filename
            downloads[task_id]['status'] = 'completed'
            downloads[task_id]['progress'] = 100
        else:
            raise Exception("URL de téléchargement non trouvée")
        
    except Exception as e:
        print(f"[EXCEPTION] {str(e)}")
        downloads[task_id]['status'] = 'error'
        downloads[task_id]['error'] = str(e)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search')
def search():
    query = request.args.get('q', '').strip()
    if not query:
        return jsonify({'results': []})
    results = search_youtube(query, limit=15)
    return jsonify({'results': results})

@app.route('/watch/<video_id>')
def watch(video_id):
    video = {
        'id': video_id,
        'title': 'Vidéo',
        'embed_url': f"https://www.youtube.com/embed/{video_id}",
        'url': f"https://youtube.com/watch?v={video_id}"
    }
    return render_template('watch.html', video=video)

@app.route('/download', methods=['POST'])
def start_download():
    url = request.form.get('url')
    format_type = request.form.get('format', 'mp3')
    quality = request.form.get('quality', 'best')
    if not url:
        return jsonify({'error': 'URL requise'}), 400
    task_id = str(int(time.time() * 1000))
    thread = threading.Thread(target=download_worker, args=(task_id, url, format_type, quality))
    thread.daemon = True
    thread.start()
    return jsonify({'task_id': task_id})

@app.route('/status/<task_id>')
def get_status(task_id):
    if task_id not in downloads:
        return jsonify({'error': 'Task not found'}), 404
    data = downloads[task_id].copy()
    if data['status'] == 'completed':
        data['download_url'] = f"/file/{data['filename']}"
    return jsonify(data)

@app.route('/file/<filename>')
def download_file(filename):
    filepath = os.path.join(app.config['DOWNLOAD_FOLDER'], filename)
    if not os.path.exists(filepath):
        return "Fichier non trouvé", 404
    return send_file(filepath, as_attachment=True)

@app.route('/list')
def list_files():
    files = []
    for f in os.listdir(app.config['DOWNLOAD_FOLDER']):
        path = os.path.join(app.config['DOWNLOAD_FOLDER'], f)
        if os.path.isfile(path):
            size = os.path.getsize(path) / (1024 * 1024)
            ext = f.split('.')[-1].upper()
            files.append({
                'name': f,
                'size': round(size, 2),
                'ext': ext,
                'url': f"/file/{f}"
            })
    return jsonify(files)

@app.route('/delete/<filename>', methods=['DELETE'])
def delete_file(filename):
    filepath = os.path.join(app.config['DOWNLOAD_FOLDER'], filename)
    if os.path.exists(filepath):
        os.remove(filepath)
        return jsonify({'status': 'deleted'})
    return jsonify({'error': 'Fichier non trouvé'}), 404

if __name__ == '__main__':
    print("🔥 BOT MUSIC/VIDEO - API SECOURS")
    print(f"📁 Dossier: {app.config['DOWNLOAD_FOLDER']}")
    print("🌐 http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=False)
