# 🎵 X STUDIO - Music & Video Downloader

Application web de recherche, téléchargement et lecture de musique/vidéos sur Android (Termux).

---

## 📦 Dépendances à installer

```bash
pkg update -y && pkg upgrade -y
pkg install python python-pip ffmpeg termux-api -y
pip install flask yt-dlp python-dotenv requests
