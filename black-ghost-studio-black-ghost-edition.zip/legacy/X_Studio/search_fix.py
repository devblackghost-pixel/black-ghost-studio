import re
import json
import urllib.request
import urllib.parse

def search_youtube(query, limit=10):
    try:
        # Méthode alternative : scraping direct
        encoded_query = urllib.parse.quote(query)
        url = f"https://www.youtube.com/results?search_query={encoded_query}"
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        req = urllib.request.Request(url, headers=headers)
        response = urllib.request.urlopen(req)
        html = response.read().decode('utf-8')
        
        # Extraction des données JSON des vidéos
        pattern = r'ytInitialData\s*=\s*({.*?});'
        match = re.search(pattern, html)
        if not match:
            return []
        
        data = json.loads(match.group(1))
        videos = []
        
        # Parcours du JSON pour extraire les vidéos
        try:
            contents = data['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
            for content in contents:
                if 'itemSectionRenderer' in content:
                    items = content['itemSectionRenderer']['contents']
                    for item in items:
                        if 'videoRenderer' in item:
                            v = item['videoRenderer']
                            video_id = v.get('videoId', '')
                            title = v.get('title', {}).get('runs', [{}])[0].get('text', 'Sans titre')
                            channel = v.get('ownerText', {}).get('runs', [{}])[0].get('text', 'Inconnu')
                            duration = v.get('lengthText', {}).get('simpleText', '')
                            views = v.get('viewCountText', {}).get('simpleText', '')
                            thumbnails = v.get('thumbnail', {}).get('thumbnails', [{}])
                            thumb_url = thumbnails[-1].get('url', '') if thumbnails else ''
                            
                            videos.append({
                                'id': video_id,
                                'title': title,
                                'channel': channel,
                                'duration': duration,
                                'views': views,
                                'thumbnails': thumb_url,
                                'url': f"https://youtube.com/watch?v={video_id}"
                            })
                            if len(videos) >= limit:
                                break
                if len(videos) >= limit:
                    break
        except Exception as e:
            print(f"Erreur parsing: {e}")
        
        return videos
    except Exception as e:
        print(f"Erreur recherche: {e}")
        return []

# Test
if __name__ == "__main__":
    results = search_youtube("extension", limit=5)
    for v in results:
        print(f"{v['title']} - {v['channel']}")
