import os
import re
import threading
import time
import json
import urllib.request
import urllib.parse
import subprocess
from flask import Flask, render_template, request, jsonify, send_file
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
YOUTUBE_COOKIES = os.path.expanduser("~/cookies/cookies.txt")

INTERNAL_STORAGE = "/storage/emulated/0"
DOWNLOAD_PATH = os.path.join(INTERNAL_STORAGE, "Music", "X_Studio")
if not os.path.exists(DOWNLOAD_PATH):
    DOWNLOAD_PATH = os.path.join(os.getcwd(), 'downloads')
os.makedirs(DOWNLOAD_PATH, exist_ok=True)

app.config['DOWNLOAD_FOLDER'] = DOWNLOAD_PATH
downloads = {}
download_tasks = {}

print("""
╔═══════════════════════════════════════════╗
║         X STUDIO - RED & BLACK            ║
║         Music & Video Downloader          ║
╚═══════════════════════════════════════════╝
""")
print(f"[+] Dossier: {DOWNLOAD_PATH}")
print(f"[+] http://localhost:5003")

POPULAR_SUGGESTIONS = ["afro beat 2024", "amapiano mix", "taylor swift", "travis scott", "remix 2024", "rnb 2024", "drake", "weeknd", "billie eilish", "bad bunny", "megan thee stallion", "kendrick lamar", "sza", "french rap 2024", "ninho", "gazo", "wizkid", "burna boy", "asake", "rema", "central cee", "dave", "stormzy", "hip hop 2024", "pop 2024"]
TRENDING_VIDEOS = ["dQw4w9WgXcQ", "kJQP7kiw5Fk", "fJ9rUzIMcZQ", "YQHsXMglC9A", "RgKAFK5djSk", "CevxZvSJLk8", "OPf0YbXqDm0", "JGwWNGJdvx8", "hT_nvWreIhg", "nlcIKh6sBtc", "fRh_vgS2dFE", "0yW7w8F2TVA"]

def search_youtube(query, limit=15):
    try:
        encoded_query = urllib.parse.quote(query)
        url = f"https://www.youtube.com/results?search_query={encoded_query}"
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'}
        req = urllib.request.Request(url, headers=headers)
        response = urllib.request.urlopen(req, timeout=15)
        html = response.read().decode('utf-8')
        pattern = r'ytInitialData\s*=\s*({.*?});'
        match = re.search(pattern, html)
        if not match:
            return []
        data = json.loads(match.group(1))
        videos = []
        try:
            contents = data['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
            for content in contents:
                if 'itemSectionRenderer' in content:
                    items = content['itemSectionRenderer']['contents']
                    for item in items:
                        if 'videoRenderer' in item:
                            v = item['videoRenderer']
                            video_id = v.get('videoId', '')
                            title = v.get('title', {}).get('runs', [{}])[0].get('text', 'Sans titre')
                            channel = v.get('ownerText', {}).get('runs', [{}])[0].get('text', 'Inconnu')
                            duration = v.get('lengthText', {}).get('simpleText', '')
                            views = v.get('viewCountText', {}).get('simpleText', '')
                            thumbnails = v.get('thumbnail', {}).get('thumbnails', [{}])
                            thumb_url = thumbnails[-1].get('url', '') if thumbnails else ''
                            videos.append({'id': video_id, 'title': title, 'channel': channel, 'duration': duration, 'views': views, 'thumbnails': thumb_url, 'url': f"https://youtube.com/watch?v={video_id}", 'embed_url': f"https://www.youtube.com/embed/{video_id}"})
                            if len(videos) >= limit:
                                break
                if len(videos) >= limit:
                    break
        except Exception as e:
            print(f"Erreur parsing: {e}")
        return videos
    except Exception as e:
        print(f"Erreur recherche: {e}")
        return []

def get_trending_videos():
    videos = []
    for vid_id in TRENDING_VIDEOS[:10]:
        try:
            thumb = f"https://i.ytimg.com/vi/{vid_id}/hqdefault.jpg"
            videos.append({'id': vid_id, 'title': 'Vidéo tendance', 'channel': 'YouTube', 'duration': '', 'views': '', 'thumbnails': thumb, 'url': f"https://youtube.com/watch?v={vid_id}", 'embed_url': f"https://www.youtube.com/embed/{vid_id}"})
        except:
            continue
    return videos

def send_notification(title, message, filepath=None):
    try:
        os.system(f"termux-notification -t 'X Studio 🎵' -c '{title} ✅' --priority high")
        if filepath and os.path.exists(filepath):
            os.system(f"termux-notification -t 'X Studio' -c '▶️ {title}' --action 'termux-open {filepath}'")
    except Exception as e:
        print(f"[NOTIF] Erreur: {e}")

def open_with_player(filepath):
    try:
        if os.path.exists(filepath):
            os.system(f"termux-open '{filepath}'")
            return True
    except Exception as e:
        print(f"[OPEN] Erreur: {e}")
    return False

def download_worker(task_id, url, format_type, quality):
    downloads[task_id] = {'status': 'started', 'progress': 0, 'filename': '', 'error': ''}
    download_tasks[task_id] = {'id': task_id, 'url': url, 'title': 'Chanson', 'filename': '', 'progress': 0, 'status': 'started'}
    try:
        downloads[task_id]['progress'] = 10
        download_tasks[task_id]['progress'] = 10
        downloads[task_id]['status'] = 'processing'
        download_tasks[task_id]['status'] = 'processing'
        if not os.path.isfile(YOUTUBE_COOKIES):
            raise FileNotFoundError(f"Fichier cookies introuvable : {YOUTUBE_COOKIES}")
        before_files = {name for name in os.listdir(DOWNLOAD_PATH)}
        output_template = os.path.join(DOWNLOAD_PATH, '%(title)s.%(ext)s')
        common_args = ['yt-dlp', '--cookies', YOUTUBE_COOKIES, '--no-check-certificate', '--newline', '--no-playlist', '--restrict-filenames', '--force-overwrites', '--print', 'after_move:filepath']
        if format_type == 'mp3':
            cmd = common_args + ['-f', 'bestaudio/best', '--extract-audio', '--audio-format', 'mp3', '--audio-quality', '0', '-o', output_template, '--embed-thumbnail', '--add-metadata', url]
        else:
            if quality == 'best':
                fmt = 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
            elif quality == '720p':
                fmt = 'bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[height<=720][ext=mp4]'
            else:
                fmt = 'best[ext=mp4]'
            cmd = common_args + ['-f', fmt, '-o', output_template, '--merge-output-format', 'mp4', url]
        print(f"[CMD] yt-dlp --cookies [configured] {' '.join(cmd[2:])}")
        downloads[task_id]['progress'] = 30
        download_tasks[task_id]['progress'] = 30
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, universal_newlines=True)
        output_lines = []
        detected_path = ''
        for line in process.stdout:
            clean_line = line.strip()
            if clean_line:
                output_lines.append(clean_line)
                print(f"[YT-DLP] {clean_line}")
            if os.path.isabs(clean_line) and os.path.isfile(clean_line):
                detected_path = clean_line
            if '%' in clean_line:
                match = re.search(r'(\d+\.?\d*)%', clean_line)
                if match:
                    pct = float(match.group(1))
                    downloads[task_id]['progress'] = 30 + (pct * 0.7)
                    download_tasks[task_id]['progress'] = 30 + (pct * 0.7)
            if 'Merging' in clean_line or 'Converting' in clean_line or 'Writing' in clean_line:
                downloads[task_id]['status'] = 'processing'
                download_tasks[task_id]['status'] = 'processing'
        process.wait()
        if process.returncode != 0:
            safe_error = '\\n'.join(output_lines[-8:])[-1800:]
            print(f"[ERROR] yt-dlp code {process.returncode}: {safe_error}")
            downloads[task_id]['status'] = 'error'
            download_tasks[task_id]['status'] = 'error'
            downloads[task_id]['error'] = safe_error or f"Erreur code {process.returncode}"
            download_tasks[task_id]['error'] = safe_error or f"Erreur code {process.returncode}"
            return
        new_files = [os.path.join(DOWNLOAD_PATH, name) for name in os.listdir(DOWNLOAD_PATH) if name not in before_files]
        candidates = [path for path in new_files if os.path.isfile(path)]
        latest = detected_path if detected_path and os.path.isfile(detected_path) else (max(candidates, key=os.path.getctime) if candidates else '')
        if not latest:
            downloads[task_id]['status'] = 'error'
            download_tasks[task_id]['status'] = 'error'
            downloads[task_id]['error'] = "yt-dlp a terminé sans fichier écrit dans downloads"
            download_tasks[task_id]['error'] = "yt-dlp a terminé sans fichier écrit dans downloads"
            return
        filename = os.path.basename(latest)
        downloads[task_id]['filename'] = filename
        downloads[task_id]['status'] = 'completed'
        downloads[task_id]['progress'] = 100
        download_tasks[task_id]['filename'] = filename
        download_tasks[task_id]['title'] = os.path.splitext(filename)[0]
        download_tasks[task_id]['status'] = 'completed'
        download_tasks[task_id]['progress'] = 100
        print(f"[SUCCESS] {latest}")
        send_notification(os.path.splitext(filename)[0], filename.split('.')[-1].upper(), latest)
        os.system(f"termux-media-scan '{latest}' 2>/dev/null")
    except Exception as e:
        print(f"[EXCEPTION] {str(e)}")
        downloads[task_id]['status'] = 'error'
        download_tasks[task_id]['status'] = 'error'
        downloads[task_id]['error'] = str(e)
        download_tasks[task_id]['error'] = str(e)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search')
def search():
    query = request.args.get('q', '').strip()
    if not query:
        return jsonify({'results': []})
    results = search_youtube(query, limit=15)
    return jsonify({'results': results})

@app.route('/trending')
def trending():
    return jsonify({'results': get_trending_videos()})

@app.route('/suggestions')
def suggestions():
    query = request.args.get('q', '').strip().lower()
    if not query:
        return jsonify({'suggestions': []})
    matches = [s for s in POPULAR_SUGGESTIONS if query in s.lower()]
    if len(matches) < 5:
        generic = [f"{query} music", f"{query} song", f"{query} video", f"{query} official", f"{query} 2024"]
        matches.extend(generic[:5-len(matches)])
    return jsonify({'suggestions': matches[:8]})

@app.route('/watch/<video_id>')
def watch(video_id):
    video = {'id': video_id, 'title': 'Vidéo', 'embed_url': f"https://www.youtube.com/embed/{video_id}", 'url': f"https://youtube.com/watch?v={video_id}"}
    return render_template('watch.html', video=video)

@app.route('/download', methods=['POST'])
def start_download():
    url = request.form.get('url')
    format_type = request.form.get('format', 'mp3')
    quality = request.form.get('quality', 'best')
    if not url:
        return jsonify({'error': 'URL requise'}), 400
    task_id = str(int(time.time() * 1000))
    thread = threading.Thread(target=download_worker, args=(task_id, url, format_type, quality))
    thread.daemon = True
    thread.start()
    return jsonify({'task_id': task_id})

@app.route('/status/<task_id>')
def get_status(task_id):
    if task_id not in downloads:
        return jsonify({'error': 'Task not found'}), 404
    return jsonify(downloads[task_id])

@app.route('/tasks')
def get_tasks():
    return jsonify(list(download_tasks.values()))

@app.route('/list')
def list_files():
    files = []
    for f in os.listdir(DOWNLOAD_PATH):
        path = os.path.join(DOWNLOAD_PATH, f)
        if os.path.isfile(path):
            size = os.path.getsize(path) / (1024 * 1024)
            ext = f.split('.')[-1].upper()
            files.append({'name': f, 'size': round(size, 2), 'ext': ext, 'url': f"/file/{f}", 'open_url': f"/open/{f}"})
    return jsonify(files)

@app.route('/file/<filename>')
def download_file(filename):
    filepath = os.path.join(DOWNLOAD_PATH, filename)
    if not os.path.exists(filepath):
        return "Fichier non trouvé", 404
    return send_file(filepath, as_attachment=True)

@app.route('/open/<filename>')
def open_file(filename):
    filepath = os.path.join(DOWNLOAD_PATH, filename)
    if not os.path.exists(filepath):
        return jsonify({'error': 'Fichier non trouvé'}), 404
    if open_with_player(filepath):
        return jsonify({'status': 'ouvert', 'file': filename})
    return jsonify({'error': 'Impossible d\'ouvrir le fichier'}), 500

@app.route('/delete/<filename>', methods=['DELETE'])
def delete_file(filename):
    filepath = os.path.join(DOWNLOAD_PATH, filename)
    if os.path.exists(filepath):
        os.remove(filepath)
        return jsonify({'status': 'deleted'})
    return jsonify({'error': 'Fichier non trouvé'}), 404

@app.route('/downloads')
def downloads_page():
    return render_template('downloads.html')

@app.route('/shazam')
def shazam_page():
    return render_template('shazam.html')

@app.route('/shazam/identify', methods=['POST'])
def shazam_identify():
    import requests, base64, time as time_lib, json as json_lib, subprocess as sp
    AUDD_API_KEY = os.getenv('AUDD_API_KEY', 'test')
    try:
        audio_file = os.path.join(os.path.expanduser("~"), f"shazam_temp_{int(time_lib.time())}.m4a")
        sp.run(['termux-microphone-record', '-f', audio_file, '-l', '8', '-e', 'aac', '-b', '128k'], capture_output=True, timeout=15)
        if not os.path.exists(audio_file) or os.path.getsize(audio_file) < 1000:
            return jsonify({'error': 'Enregistrement trop court'})
        with open(audio_file, 'rb') as f:
            audio_b64 = base64.b64encode(f.read()).decode('utf-8')
        os.remove(audio_file)
        response = requests.post("https://api.audd.io/", data={'api_token': AUDD_API_KEY, 'audio': audio_b64, 'return': 'spotify'}, timeout=30)
        result = response.json()
        if result.get('status') == 'success' and result.get('result'):
            song = result['result']
            thumbnail = ''
            if 'spotify' in song and song['spotify'] and 'album' in song['spotify'] and 'images' in song['spotify']['album']:
                images = song['spotify']['album']['images']
                if images:
                    thumbnail = images[0].get('url', '')
            return jsonify({'title': song.get('title', 'Titre inconnu'), 'artist': song.get('artist', 'Artiste inconnu'), 'album': song.get('album', ''), 'thumbnail': thumbnail, 'url': f"https://youtube.com/results?search_query={song.get('title', '')}+{song.get('artist', '')}"})
        return jsonify({'error': result.get('error', 'Chanson non reconnue')})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/shazam/upload', methods=['POST'])
def shazam_upload():
    import requests, base64
    AUDD_API_KEY = os.getenv('AUDD_API_KEY', 'test')
    try:
        file = request.files.get('file')
        if not file:
            return jsonify({'error': 'Aucun fichier'})
        audio_b64 = base64.b64encode(file.read()).decode('utf-8')
        r = requests.post('https://api.audd.io/', data={'api_token': AUDD_API_KEY, 'audio': audio_b64}, timeout=30)
        data = r.json()
        if data.get('status') == 'success' and data.get('result'):
            s = data['result']
            return jsonify({'title': s.get('title', ''), 'artist': s.get('artist', ''), 'album': s.get('album', ''), 'thumbnail': '', 'url': ''})
        return jsonify({'error': 'Non reconnu'})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/play')
def play_page():
    return render_template('play.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5005, debug=False)

# ========== STATIC ==========
from flask import send_from_directory

@app.route('/manifest.json')
def manifest():
    return send_from_directory('static', 'manifest.json')

@app.route('/sw.js')
def service_worker():
    return send_from_directory('static', 'sw.js', mimetype='application/javascript')

# ========== BIBLIOTHÈQUE MUSICALE COMPLÈTE ==========
@app.route('/library')
def library():
    """Scanne tous les dossiers musicaux du téléphone"""
    import os
    music_files = []
    
    # Dossiers à scanner
    folders = [
        os.path.expanduser("~/storage/music"),
        os.path.expanduser("~/storage/downloads"),
        os.path.expanduser("~/storage/shared/Music"),
        os.path.expanduser("~/storage/shared/Download"),
        os.path.expanduser("~/storage/shared/DCIM"),
        DOWNLOAD_PATH  # Dossier X Studio
    ]
    
    # Extensions audio autorisées
    audio_ext = {'.mp3', '.m4a', '.wav', '.flac', '.ogg', '.opus', '.aac', '.wma'}
    
    for folder in folders:
        if not os.path.exists(folder):
            continue
        for root, dirs, files in os.walk(folder):
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in audio_ext:
                    path = os.path.join(root, file)
                    size = os.path.getsize(path) / (1024 * 1024)
                    # Éviter les doublons
                    if path not in [f['path'] for f in music_files]:
                        music_files.append({
                            'name': file,
                            'path': path,
                            'size': round(size, 2),
                            'ext': ext.replace('.', '').upper(),
                            'url': f"/library/file?path={path}"
                        })
    
    return jsonify(music_files)

@app.route('/library/file')
def library_file():
    """Sert un fichier depuis la bibliothèque musicale"""
    import os
    from flask import send_file
    
    file_path = request.args.get('path')
    if not file_path:
        return jsonify({'error': 'Chemin manquant'}), 400
    
    if not os.path.exists(file_path):
        return jsonify({'error': 'Fichier non trouvé'}), 404
    
    return send_file(file_path, as_attachment=False)

# ========== VÉRIFICATION DES PERMISSIONS ==========
@app.route('/check-permission')
def check_permission():
    """Vérifie si l'accès au stockage est accordé"""
    import os
    storage_path = os.path.expanduser("~/storage")
    if os.path.exists(storage_path) and os.path.isdir(storage_path):
        return jsonify({'granted': True, 'message': '✅ Accès au stockage accordé'})
    else:
        return jsonify({'granted': False, 'message': '⚠️ Permission non accordée. Lancez: termux-setup-storage'})

@app.route('/grant-permission')
def grant_permission():
    """Demande la permission d'accès au stockage"""
    import subprocess
    try:
        subprocess.run(['termux-setup-storage'], check=True)
        return jsonify({'status': 'success', 'message': '📁 Permission demandée. Acceptez sur votre téléphone.'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})
