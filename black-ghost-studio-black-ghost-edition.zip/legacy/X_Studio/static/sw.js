self.addEventListener('install', function(e) {
    e.waitUntil(
        caches.open('xstudio-v1').then(function(cache) {
            return cache.addAll([
                '/',
                '/play',
                '/static/icon-192.png'
            ]);
        })
    );
});

self.addEventListener('activate', function(e) {
    e.waitUntil(clients.claim());
});

self.addEventListener('fetch', function(e) {
    e.respondWith(
        caches.match(e.request).then(function(response) {
            return response || fetch(e.request);
        })
    );
});
