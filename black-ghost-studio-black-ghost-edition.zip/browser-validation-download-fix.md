
## Reproduction après correction du bouton

La Preview actuelle affiche uniquement Accueil, Shazam, Play et Téléchargements. Le bouton MP3 déclenche bien la notification interne « Téléchargement MP3 », avec « Tentative publique 1/3 » et « 1 % ». Le test doit encore attendre l’état final pour confirmer l’apparition du lien « RÉCUPÉRER LE FICHIER » et vérifier la récupération réelle du fichier.

## Preuve de récupération réelle

Après l’état « MP3 prêt — 100 % », l’interface affiche le lien « RÉCUPÉRER LE FICHIER ». Le clic sur ce lien a créé deux entrées dans `chrome://downloads/`, dont `Rick Astley - Never Gonna Give You Up (Official Video) (4K Remaster) (1).mp3`. Cette vérification confirme que le navigateur reçoit réellement un fichier MP3 ; le problème précédent était l’ouverture directe de l’URL CloudFront comme lecteur audio au lieu d’une réponse avec `Content-Disposition: attachment`.
