export type CookieValidation = {
  status: "valid" | "incomplete" | "invalid";
  message: string;
  found: string[];
};

const SESSION_COOKIE_NAMES = ["SID", "HSID", "SSID", "SAPISID", "__Secure-1PSID", "__Secure-3PSID"];

export function validateCookieContents(contents: string): CookieValidation {
  const lines = contents.split(/\r?\n/);
  const names = lines.map((line) => line.split("\t")[5]).filter(Boolean);
  const found = SESSION_COOKIE_NAMES.filter((name) => names.includes(name));
  if (!contents.includes("# Netscape HTTP Cookie File")) {
    return { status: "invalid", found, message: "Format non reconnu. Utilisez un export Netscape cookies.txt." };
  }
  if (found.length < 2) {
    return { status: "incomplete", found, message: "Le fichier est lisible, mais il manque des cookies de session importants." };
  }
  return { status: "valid", found, message: "Export Netscape valide : cookies de session détectés." };
}
