import { describe, expect, it } from "vitest";
import { validateCookieContents } from "./cookieValidation";

const header = "# Netscape HTTP Cookie File\n";

describe("validateCookieContents", () => {
  it("accepts a Netscape export with session cookies", () => {
    const contents = `${header}.youtube.com\tTRUE\t/\tTRUE\t0\tSID\tvalue\n.youtube.com\tTRUE\t/\tTRUE\t0\tSAPISID\tvalue\n`;
    expect(validateCookieContents(contents).status).toBe("valid");
  });

  it("marks a Netscape export without sessions as incomplete", () => {
    const contents = `${header}.youtube.com\tTRUE\t/\tTRUE\t0\tPREF\tvalue\n`;
    expect(validateCookieContents(contents).status).toBe("incomplete");
  });

  it("rejects a file without the Netscape header", () => {
    expect(validateCookieContents("not a cookie export").status).toBe("invalid");
  });
});
