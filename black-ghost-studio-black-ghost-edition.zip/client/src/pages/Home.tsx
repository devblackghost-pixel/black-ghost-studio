import { useEffect, useMemo, useRef, useState } from "react";
import {
  AudioLines,
  ChevronLeft,
  ChevronRight,
  Download,
  Flame,
  Ghost,
  Home as HomeIcon,
  Library,
  ListMusic,
  Menu,
  Pause,
  Play,
  Repeat,
  Search,
  Shuffle,
  SkipBack,
  SkipForward,
  Trash2,
  Volume2,
  X,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const audioFiles = [
  {
    id: "headlights",
    title: "Headlights",
    artist: "Alok, Alan Walker · KIDDO",
    fileName: "Alok, Alan Walker - Headlights (Lyrics) ft. KIDDO.mp3",
    url: "/manus-storage/headlights_3ded43a2.mp3",
    cover: "https://i.ytimg.com/vi/6VQYg6L9m3A/hqdefault.jpg",
  },
  {
    id: "seiyu",
    title: "SEIYU",
    artist: "NEGRITO SENPAI",
    fileName: "NEGRITO SENPAI - SEIYU (AMV ANIME MIX).mp3",
    url: "/manus-storage/seiyu_6b7de9bf.mp3",
    cover: "https://i.ytimg.com/vi/6Qb9k7vQ3mU/hqdefault.jpg",
  },
  {
    id: "never-gonna-give-you-up",
    title: "Never Gonna Give You Up",
    artist: "Rick Astley",
    fileName: "Rick Astley - Never Gonna Give You Up (Official Video) (4K Remaster) [dQw4w9WgXcQ].mp3",
    url: "/manus-storage/never-gonna-give-you-up_464f74bf.mp3",
    cover: "https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg",
  },
  {
    id: "moonlight",
    title: "MOONLIGHT",
    artist: "XXXTENTACION",
    fileName: "XXXTENTACION - MOONLIGHT (OFFICIAL MUSIC VIDEO).mp3",
    url: "/manus-storage/moonlight_522e1c33.mp3",
    cover: "https://i.ytimg.com/vi/9Gq9QyKjR9M/hqdefault.jpg",
  },
  {
    id: "mortals",
    title: "Mortals Funk Remix",
    artist: "Solo Leveling · AMV",
    fileName: "「AMV」Mortals Funk Remix ｜ Solo Leveling.mp3",
    url: "/manus-storage/mortals_586d9590.mp3",
    cover: "https://i.ytimg.com/vi/7pG7M7G6t8A/hqdefault.jpg",
  },
];

const trending = [
  { title: "Never Gonna Give You Up", artist: "Rick Astley", videoId: "dQw4w9WgXcQ" },
  { title: "Shape of You", artist: "Ed Sheeran", videoId: "JGwWNGJdvx8" },
  { title: "Blinding Lights", artist: "The Weeknd", videoId: "4NRXx6U8ABQ" },
  { title: "Despacito", artist: "Luis Fonsi · Daddy Yankee", videoId: "kJQP7kiw5Fk" },
  { title: "Believer", artist: "Imagine Dragons", videoId: "7wtfhZwyrcc" },
  { title: "Someone Like You", artist: "Adele", videoId: "hLQl3WQQoQ0" },
];

type Page = "Accueil" | "Shazam" | "Play" | "Téléchargements";
type InstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed" }> };

function formatTime(value: number) {
  if (!Number.isFinite(value)) return "0:00";
  const minutes = Math.floor(value / 60);
  const seconds = Math.floor(value % 60).toString().padStart(2, "0");
  return `${minutes}:${seconds}`;
}

export default function Home() {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [page, setPage] = useState<Page>("Accueil");
  const [query, setQuery] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [remoteResults, setRemoteResults] = useState<typeof trending>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [downloadState, setDownloadState] = useState("");
  const [downloadNotice, setDownloadNotice] = useState<{ format: "mp3" | "video"; progress: number; status: "queued" | "downloading" | "completed" | "error"; message: string; url?: string; fileUrl?: string; filename?: string } | null>(null);
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
  const [remoteLibrary, setRemoteLibrary] = useState(audioFiles);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [repeat, setRepeat] = useState(false);
  const [shuffle, setShuffle] = useState(false);
  const [removedIds, setRemovedIds] = useState<string[]>(() => {
    if (typeof window === "undefined") return [];
    try { return JSON.parse(localStorage.getItem("xstudio-removed-songs") || "[]"); } catch { return []; }
  });
  const [menuOpen, setMenuOpen] = useState(false);
  const [audioError, setAudioError] = useState("");
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [installMessage, setInstallMessage] = useState("");

  useEffect(() => {
    const handleInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", handleInstallPrompt);
    return () => window.removeEventListener("beforeinstallprompt", handleInstallPrompt);
  }, []);

  const installApplication = async () => {
    if (!installPrompt) {
      setInstallMessage("Utilisez le menu de votre navigateur : Installer Black Ghost Studio ou Ajouter à l’écran d’accueil.");
      return;
    }
    const pendingPrompt = installPrompt;
    setInstallPrompt(null);
    setInstallMessage("Choisissez Installer dans la boîte de dialogue du navigateur, ou utilisez le menu du navigateur pour Ajouter X Studio à l’écran d’accueil.");
    try {
      await pendingPrompt.prompt();
      const choice = await Promise.race([
        pendingPrompt.userChoice,
        new Promise<{ outcome: "accepted" | "dismissed" }>((resolve) => window.setTimeout(() => resolve({ outcome: "dismissed" }), 1500)),
      ]);
      setInstallMessage(choice.outcome === "accepted" ? "Black Ghost Studio est installé sur votre appareil." : "Si aucune boîte ne s’est ouverte, utilisez le menu du navigateur : Installer Black Ghost Studio ou Ajouter à l’écran d’accueil.");
    } catch {
      setInstallMessage("Utilisez le menu du navigateur : Installer Black Ghost Studio ou Ajouter à l’écran d’accueil.");
    }
  };

  useEffect(() => {
    fetch("/api/xstudio/library")
      .then((response) => response.json())
      .then((items) => setRemoteLibrary((items || []).map((item: typeof audioFiles[number]) => ({ ...audioFiles.find((song) => song.id === item.id), ...item, cover: audioFiles.find((song) => song.id === item.id)?.cover || "https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg" }))))
      .catch(() => setRemoteLibrary(audioFiles));
  }, []);

  const songs = useMemo(() => remoteLibrary.filter((song) => !removedIds.includes(song.id)), [remoteLibrary, removedIds]);
  const currentSong = songs.find((song) => song.id === currentId) ?? null;

  useEffect(() => {
    if (!audioRef.current || !currentSong) return;
    audioRef.current.src = currentSong.url;
    audioRef.current.volume = volume;
  }, [currentSong]);

  useEffect(() => {
    if (!searchTerm) {
      setRemoteResults([]);
      return;
    }
    const controller = new AbortController();
    setSearchLoading(true);
    fetch(`/api/xstudio/search?q=${encodeURIComponent(searchTerm)}`, { signal: controller.signal })
      .then((response) => response.json())
      .then((payload) => setRemoteResults((payload.results || []).map((item: { id: string; title: string; channel?: string }) => ({ title: item.title, artist: item.channel || "YouTube", videoId: item.id }))))
      .catch(() => setRemoteResults([]))
      .finally(() => setSearchLoading(false));
    return () => controller.abort();
  }, [searchTerm]);

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume;
  }, [volume]);

  const removeSong = (id: string) => {
    if (!window.confirm("Supprimer ce morceau de votre bibliothèque ?")) return;
    setRemovedIds((ids) => {
      const next = [...ids, id];
      localStorage.setItem("xstudio-removed-songs", JSON.stringify(next));
      return next;
    });
    if (currentId === id) { audioRef.current?.pause(); setCurrentId(null); setIsPlaying(false); }
  };

  const playSong = (id: string) => {
    const song = songs.find((item) => item.id === id);
    setCurrentId(id);
    setPage("Play");
    if (!audioRef.current || !song) return;
    setAudioError("");
    audioRef.current.src = song.url;
    audioRef.current.volume = volume;
    audioRef.current.currentTime = 0;
    const request = audioRef.current.play();
    request.then(() => { setAudioError(""); setIsPlaying(true); }).catch(() => setAudioError("Appuyez sur Lecture pour autoriser la lecture audio dans votre navigateur."));
  };

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (!currentSong) {
      if (songs[0]) playSong(songs[0].id);
      return;
    }
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => { setAudioError(""); setIsPlaying(true); }).catch(() => setIsPlaying(false));
    }
  };

  const moveSong = (direction: 1 | -1) => {
    if (!songs.length) return;
    const index = Math.max(0, songs.findIndex((song) => song.id === currentId));
    const nextIndex = shuffle
      ? Math.floor(Math.random() * songs.length)
      : (index + direction + songs.length) % songs.length;
    playSong(songs[nextIndex].id);
  };

  const handleEnded = () => {
    if (repeat && audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play();
      return;
    }
    moveSong(1);
  };

  const filteredResults = searchTerm ? remoteResults : trending;

  const handleSearch = (event: React.FormEvent) => {
    event.preventDefault();
    const term = query.trim();
    setSearchTerm(term);
    setPage("Accueil");
    if (!term) setDownloadState("");
  };

  const downloadVideo = async (videoId: string, format: "mp3" | "video") => {
    const label = format === "mp3" ? "MP3" : "vidéo";
    setDownloadState(`Téléchargement ${label} en cours…`);
    setDownloadNotice({ format, progress: 0, status: "queued", message: `Préparation du téléchargement ${label}…` });
    try {
      const response = await fetch("/api/xstudio/download", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url: `https://youtube.com/watch?v=${videoId}`, format, quality: "best" }) });
      const payload = await response.json();
      if (!response.ok || !payload.taskId) throw new Error(payload.error || "Téléchargement impossible");
      const events = new EventSource(`/api/xstudio/download-progress/${payload.taskId}`);
      events.onmessage = (event) => {
        const task = JSON.parse(event.data) as { format: "mp3" | "video"; progress: number; status: "queued" | "downloading" | "completed" | "error"; message: string; filename?: string; url?: string; key?: string; fileToken?: string };
        const fileUrl = task.status === "completed" && task.fileToken ? `/api/xstudio/download-file/${payload.taskId}?token=${encodeURIComponent(task.fileToken)}` : undefined;
        const visibleTask = { ...task, fileUrl };
        setDownloadNotice(visibleTask);
        setDownloadState(task.status === "completed" ? `${label} prêt : ${task.filename || "fichier disponible"}` : task.message);
        if (task.status === "completed" && fileUrl) {
          const link = document.createElement("a");
          link.href = fileUrl;
          link.download = task.filename || `x-studio.${task.format === "mp3" ? "mp3" : "mp4"}`;
          document.body.appendChild(link);
          link.click();
          link.remove();
        }
        if (task.status === "completed" || task.status === "error") events.close();
      };
      events.onerror = () => {
        events.close();
        window.setTimeout(async () => {
          try {
            const statusResponse = await fetch(`/api/xstudio/download-progress/${payload.taskId}`);
            const latest = await statusResponse.json();
            if (latest.status === "completed" && latest.fileToken) {
              const fileUrl = `/api/xstudio/download-file/${payload.taskId}?token=${encodeURIComponent(latest.fileToken)}`;
              setDownloadNotice({ ...latest, fileUrl });
              setDownloadState(`${label} prêt : ${latest.filename || "fichier disponible"}`);
              return;
            }
            if (latest.status === "error") {
              setDownloadNotice(latest);
              setDownloadState(latest.message);
              return;
            }
            setDownloadNotice((current) => current ? { ...current, message: "Téléchargement toujours en cours…" } : current);
          } catch {
            setDownloadNotice((current) => current ? { ...current, status: "error", message: "Le fichier final n’est pas disponible." } : current);
          }
        }, 1200);
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Téléchargement impossible";
      setDownloadState(message);
      setDownloadNotice({ format, progress: 0, status: "error", message });
    }
  };


  const navItems: { label: Page; icon: typeof HomeIcon }[] = [
    { label: "Accueil", icon: HomeIcon },
    { label: "Shazam", icon: Zap },
    { label: "Play", icon: Play },
    { label: "Téléchargements", icon: Download },
  ];

  return (
    <div className="x-app-shell">
      <audio
        ref={audioRef}
        onTimeUpdate={(event) => setCurrentTime(event.currentTarget.currentTime)}
        onLoadedMetadata={(event) => setDuration(event.currentTarget.duration)}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onEnded={handleEnded}
        onError={() => setAudioError("Ce fichier audio ne peut pas être lu pour le moment.")}
      />

      <aside className={`x-sidebar ${menuOpen ? "is-open" : ""}`}>
        <div className="x-brand">
          <div className="x-brand-mark"><Ghost size={31} strokeWidth={1.8} /></div>
          <div>
            <div className="x-brand-name">BLACK GHOST</div>
            <div className="x-brand-tagline">NOIR / SPECTRAL EDITION</div>
          </div>
          <button className="x-close-menu" onClick={() => setMenuOpen(false)} aria-label="Fermer le menu"><X size={18} /></button>
        </div>
        <div className="x-side-line" />
        <div className="x-side-label">NAVIGATION</div>
        <nav className="x-nav" aria-label="Navigation principale">
          {navItems.map(({ label, icon: Icon }) => (
            <button key={label} className={`x-nav-item ${page === label ? "active" : ""}`} onClick={() => { setPage(label); setMenuOpen(false); }}>
              <Icon size={18} /> <span>{label}</span>
              {label === "Play" && currentSong && <span className="x-nav-dot" />}
            </button>
          ))}
        </nav>
        <div className="x-sidebar-bottom">
          <div className="x-mini-now">
            <AudioLines size={17} />
            <div><strong>{currentSong?.title ?? "Prêt à écouter"}</strong><span>{currentSong?.artist ?? "Votre bibliothèque locale"}</span></div>
          </div>
          <div className="x-edition">BLACK GHOST <span>◈</span> MUSIC PLAYER</div>
        </div>
      </aside>

      <main className="x-main">
        <header className="x-topbar">
          <button className="x-menu-button" onClick={() => setMenuOpen(true)} aria-label="Ouvrir le menu"><Menu size={21} /></button>
          <div className="x-mobile-title"><span>BLACK</span> GHOST</div>
          <div className="x-topbar-actions">
            <button className="x-install-button" onClick={installApplication} type="button" title="Installer Black Ghost Studio en application Web"><Download size={14} /> INSTALLER L’APPLICATION</button>
            <div className="x-status"><span className="x-status-light" /> SYSTEM ONLINE</div>
          </div>
        </header>

        <div className="x-content">
          {installMessage && <div className="x-install-message" role="status">{installMessage}</div>}
          {page === "Accueil" && (
            <section className="x-page-enter">
              <div className="x-hero-copy">
                <div className="x-kicker"><span /> MUSIC DISCOVERY <span /></div>
                <h1>Votre musique.<br /><em>Votre univers.</em></h1>
                <p>Recherchez, téléchargez et écoutez vos morceaux préférés dans une expérience conçue pour les passionnés.</p>
              </div>
              <form className="x-search" onSubmit={handleSearch}>
                <Search size={19} />
                <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Rechercher un son, un artiste..." aria-label="Rechercher sur YouTube" />
                <Button type="submit"><Search size={16} /> RECHERCHER</Button>
              </form>
              {searchTerm && (
                <div className="x-search-result-note">Résultats internes pour <strong>“{searchTerm}”</strong></div>
              )}
              {downloadNotice && <div className={`x-download-notice ${downloadNotice.status}`}><div className="x-download-notice-top"><div><strong>{downloadNotice.format === "mp3" ? "Téléchargement MP3" : "Téléchargement vidéo"}</strong><span>{downloadNotice.message}</span></div><b>{downloadNotice.progress}%</b></div><div className="x-download-progress"><span style={{ width: `${downloadNotice.progress}%` }} /></div>{downloadNotice.status === "completed" && downloadNotice.fileUrl && <a className="x-download-ready" href={downloadNotice.fileUrl} download={downloadNotice.filename || `x-studio.${downloadNotice.format === "mp3" ? "mp3" : "mp4"}`}><Download size={15} /> RÉCUPÉRER LE FICHIER</a>}</div>}
              <div className="x-section-heading"><div><span className="x-section-icon"><Flame size={17} /></span><div><small>À NE PAS MANQUER</small><h2>{searchTerm ? "Résultats de recherche" : "Tendances du moment"}</h2></div></div><span className="x-section-count">{searchLoading ? "CHARGEMENT" : `${filteredResults.length} VIDÉOS`}</span></div>
              {activeVideoId && <div className="x-inline-video"><div className="x-inline-video-head"><strong>Lecture vidéo intégrée</strong><button className="x-icon-button" onClick={() => setActiveVideoId(null)} aria-label="Fermer la vidéo"><X size={17} /></button></div><iframe src={`https://www.youtube-nocookie.com/embed/${activeVideoId}?autoplay=1&rel=0`} title="Lecteur vidéo Black Ghost Studio" allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen /></div>}
              {searchTerm && filteredResults[0] && <div className="x-download-action"><span>{downloadState || "Téléchargez le premier résultat directement en MP3."}</span><button onClick={() => downloadVideo(filteredResults[0].videoId, "mp3")}><Download size={15} /> TÉLÉCHARGER MP3</button><button onClick={() => downloadVideo(filteredResults[0].videoId, "video")}><Play size={15} /> TÉLÉCHARGER VIDÉO</button></div>}
              {searchTerm && filteredResults.length === 0 ? (
                <div className="x-empty-state x-search-empty"><Search size={24} /><strong>Aucun résultat dans les tendances locales</strong><span>Essayez un autre titre ou artiste pour lancer une nouvelle recherche interne.</span></div>
              ) : (
                <div className="x-trending-grid">
                  {(searchTerm ? filteredResults : trending).map((item, index) => (
                    <div className="x-video-card" key={item.videoId}>
                      <button className="x-video-main-action" onClick={() => setActiveVideoId(item.videoId)} aria-label={`Regarder ${item.title} dans Black Ghost Studio`}><div className="x-video-thumb"><img src={`https://i.ytimg.com/vi/${item.videoId}/hqdefault.jpg`} alt="" /><span className="x-video-play"><Play size={15} fill="currentColor" /></span><span className="x-video-index">0{index + 1}</span></div></button>
                      <div className="x-video-meta"><strong>{item.title}</strong><span>{item.artist}</span><small>SOURCE INTERNE <b>·</b> TENDANCE</small></div>
                      <div className="x-video-actions"><button onClick={() => downloadVideo(item.videoId, "mp3")}><Download size={14} /> MP3</button><button onClick={() => downloadVideo(item.videoId, "video")}><Play size={14} /> VIDÉO</button></div>
                    </div>
                  ))}
                </div>
              )}
              <section className="x-library-preview">
                <div className="x-section-heading compact"><div><span className="x-section-icon"><Library size={17} /></span><div><small>VOTRE COLLECTION</small><h2>Bibliothèque locale</h2></div></div><button className="x-text-button" onClick={() => setPage("Téléchargements")}>VOIR TOUT <ChevronRight size={15} /></button></div>
                <div className="x-song-strip">{songs.slice(0, 4).map((song) => <button className="x-strip-song" key={song.id} onClick={() => playSong(song.id)}><img src={song.cover} alt="" /><span><strong>{song.title}</strong><small>{song.artist}</small></span><Play size={15} /></button>)}</div>
              </section>
            </section>
          )}

          {page === "Téléchargements" && (
            <section className="x-page-enter">
              <div className="x-page-heading"><div><div className="x-kicker left"><span /> YOUR LIBRARY</div><h1>Téléchargements</h1><p>{songs.length} morceaux disponibles dans le dossier <code>downloads</code>.</p></div><div className="x-total-time"><ListMusic size={20} /><span><b>{songs.length}</b><small> PISTES</small></span></div></div>
              {audioError && <div className="x-inline-error">{audioError}</div>}
              <div className="x-download-list">
                {songs.length === 0 ? (
                  <div className="x-empty-state"><Library size={24} /><strong>Votre bibliothèque est vide</strong><span>Les morceaux placés dans <code>downloads</code> apparaîtront ici.</span></div>
                ) : songs.map((song, index) => (
                  <div className={`x-download-row ${currentId === song.id ? "current" : ""}`} key={song.id}>
                    <span className="x-row-number">{String(index + 1).padStart(2, "0")}</span><img src={song.cover} alt="" /><button className="x-row-title" onClick={() => playSong(song.id)}><strong>{song.title}</strong><span>{song.artist}</span></button><span className="x-row-type">MP3</span><a className="x-icon-button" href={song.url} download={song.fileName} aria-label={`Télécharger ${song.title}`}><Download size={17} /></a><button className="x-icon-button danger" onClick={() => removeSong(song.id)} aria-label={`Supprimer ${song.title}`}><Trash2 size={17} /></button><button className="x-row-play" onClick={() => playSong(song.id)} aria-label={`Lire ${song.title}`}>{currentId === song.id && isPlaying ? <Pause size={17} fill="currentColor" /> : <Play size={17} fill="currentColor" />}</button>
                  </div>
                ))}
              </div>
            </section>
          )}

          {page === "Play" && (
            <section className="x-page-enter x-player-page">
              <div className="x-page-heading"><div><div className="x-kicker left"><span /> NOW PLAYING</div><h1>Play</h1><p>Votre bibliothèque, en lecture continue.</p></div><div className="x-player-mode">{shuffle ? "SHUFFLE ON" : repeat ? "REPEAT ON" : "NORMAL MODE"}</div></div>
              <div className="x-player-layout">
                <div className="x-player-card">
                  <div className="x-player-art"><div className="x-art-glow" />{currentSong ? <img src={currentSong.cover} alt="" /> : <AudioLines size={58} />}</div>
                  <div className="x-player-song"><span>LECTURE EN COURS</span><h2>{currentSong?.title ?? "Aucune chanson"}</h2><p>{audioError || currentSong?.artist || "Sélectionnez un morceau dans votre bibliothèque"}</p></div>
                  <div className="x-progress-wrap"><input type="range" min="0" max={duration || 1} value={Math.min(currentTime, duration || 1)} onChange={(event) => { const value = Number(event.target.value); setCurrentTime(value); if (audioRef.current) audioRef.current.currentTime = value; }} aria-label="Progression" /><div><span>{formatTime(currentTime)}</span><span>{formatTime(duration)}</span></div></div>
                  <div className="x-player-controls"><button onClick={() => moveSong(-1)} aria-label="Précédent"><SkipBack size={20} fill="currentColor" /></button><button className="x-main-play" onClick={togglePlay} aria-label={isPlaying ? "Pause" : "Lecture"}>{isPlaying ? <Pause size={22} fill="currentColor" /> : <Play size={22} fill="currentColor" />}</button><button onClick={() => moveSong(1)} aria-label="Suivant"><SkipForward size={20} fill="currentColor" /></button></div>
                  <div className="x-player-options"><button className={repeat ? "selected" : ""} onClick={() => setRepeat((value) => !value)}><Repeat size={17} /> Répéter</button><button className={shuffle ? "selected" : ""} onClick={() => setShuffle((value) => !value)}><Shuffle size={17} /> Aléatoire</button><label><Volume2 size={17} /><input type="range" min="0" max="1" step="0.01" value={volume} onChange={(event) => setVolume(Number(event.target.value))} aria-label="Volume" /></label></div>
                </div>
                <div className="x-queue-card"><div className="x-queue-head"><div><small>QUEUE</small><h3>À suivre</h3></div><span>{songs.length} PISTES</span></div><div className="x-queue-list">{songs.map((song, index) => <button key={song.id} className={`x-queue-item ${currentId === song.id ? "active" : ""}`} onClick={() => playSong(song.id)}><span>{String(index + 1).padStart(2, "0")}</span><img src={song.cover} alt="" /><span className="x-queue-text"><strong>{song.title}</strong><small>{song.artist}</small></span>{currentId === song.id && isPlaying ? <AudioLines size={17} /> : <Play size={15} />}</button>)}</div></div>
              </div>
            </section>
          )}

          {page === "Shazam" && (
            <section className="x-page-enter x-shazam-page"><div className="x-shazam-orbit"><div className="x-shazam-core"><Zap size={50} /></div><div className="x-orbit orbit-one" /><div className="x-orbit orbit-two" /></div><div className="x-kicker"><span /> AUDIO IDENTIFICATION <span /></div><h1>Shazam</h1><p>Identifiez un morceau en quelques secondes et retrouvez-le dans votre univers Black Ghost Studio.</p><button className="x-shazam-button" onClick={() => alert("La reconnaissance audio sera disponible dans une prochaine mise à jour.")}><AudioLines size={20} /> IDENTIFIER UN MORCEAU</button><small className="x-shazam-note">FONCTIONNALITÉ PRÊTE À ÊTRE CONNECTÉE</small></section>
          )}

        </div>

        {currentSong && <div className="x-bottom-player"><div className="x-bottom-song"><img src={currentSong.cover} alt="" /><div><strong>{currentSong.title}</strong><span>{currentSong.artist}</span></div></div><div className="x-bottom-center"><button onClick={() => moveSong(-1)}><SkipBack size={16} fill="currentColor" /></button><button className="x-bottom-play" onClick={togglePlay}>{isPlaying ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" />}</button><button onClick={() => moveSong(1)}><SkipForward size={16} fill="currentColor" /></button><div className="x-bottom-progress"><span style={{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }} /></div></div><div className="x-bottom-volume"><Volume2 size={16} /><input type="range" min="0" max="1" step="0.01" value={volume} onChange={(event) => setVolume(Number(event.target.value))} aria-label="Volume" /></div></div>}
      </main>
    </div>
  );
}
