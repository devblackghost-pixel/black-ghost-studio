# Validation navigateur — mode public sans cookies

La Preview affiche la navigation Accueil, Shazam, Play et Téléchargements, sans page Cookies. Le bouton MP3 du premier résultat déclenche bien une notification interne « Téléchargement MP3 » et affiche le pourcentage « 1 % ». La stratégie publique progresse ensuite vers « Tentative publique 2/3 », ce qui confirme que les tentatives multiples sont visibles côté interface. Le téléchargement backend testé séparément atteint l’état `completed` à 100 % avec le message « MP3 prêt ».

La limite observée dans cette session navigateur est que la Preview est encore en cours de tentative au moment de la capture ; le test backend équivalent a toutefois confirmé l’état final terminé.

## Résultat final

Après les tentatives publiques, Preview affiche « MP3 prêt » et « 100 % ». Le téléchargement MP3 a donc été déclenché depuis l’interface, a affiché la progression, puis s’est terminé sans Cookies.
