# Project TODO

- [x] Implémenter l’identité visuelle stricte X Studio RED & BLACK EDITION sur toutes les pages
- [x] Créer la navigation principale avec les noms exacts : Accueil, Shazam, Play, Téléchargements
- [x] Construire la page Accueil avec recherche YouTube et vidéos tendances avec miniatures
- [x] Construire la page Téléchargements avec liste des MP3, lecture directe et suppression
- [x] Charger automatiquement la bibliothèque depuis le dossier `downloads`
- [x] Implémenter la page Play avec lecture audio réelle des chansons téléchargées
- [x] Ajouter les contrôles lecture/pause, suivant, précédent et sélection de morceau
- [x] Ajouter la barre de progression interactive et l’affichage du temps
- [x] Ajouter le réglage du volume, la répétition et la lecture aléatoire
- [x] Construire la page Shazam avec un état cohérent dans l’identité visuelle
- [x] Ajouter les états de chargement, vide et erreur pour les flux principaux
- [x] Vérifier le fonctionnement responsive sur ordinateur et mobile
- [x] Vérifier les tests Vitest existants pour les fonctionnalités serveur
- [x] Vérifier le build, les tests et le rendu final avant livraison

- [x] Ajouter la recherche YouTube via recherche externe, tendances, état vide et lien d’ouverture
- [x] Alimenter la bibliothèque à partir du catalogue de fichiers MP3 importés depuis `downloads`
- [x] Persister localement la suppression des morceaux avec confirmation et état vide
- [x] Créer la page Shazam RED & BLACK EDITION avec son état d’intégration explicite

- [x] Diagnostiquer pourquoi le site déployé apparaît vide
- [x] Restaurer les fichiers utiles de l’archive X_Studio dans `legacy/X_Studio` sans exposer `.env`
- [x] Reconnecter les fichiers audio et les données du dossier `downloads`
- [x] Vérifier que l’interface, le build et le site restauré s’affichent correctement

- [x] Corriger la barre de recherche qui ne déclenche pas correctement la recherche
- [x] Corriger la lecture automatique après sélection d’une chanson

- [x] Inventorier tous les fichiers de `X_Studio.zip` et leurs emplacements cibles
- [x] Ajouter les fichiers source, templates et scripts de X_Studio dans la nouvelle version
- [x] Ajouter les fichiers statiques et les ressources audio compatibles avec le déploiement
- [x] Installer les dépendances nécessaires sans clé API
- [x] Vérifier que chaque fichier ajouté est présent et que le site fonctionne après intégration

- [x] Analyser les routes et la logique de `legacy/X_Studio/app.py`
- [x] Ajouter les routes backend X Studio nécessaires : recherche, tendances, bibliothèque et téléchargement
- [x] Connecter l’interface aux routes de recherche, téléchargement et bibliothèque
- [x] Tester l’intégration backend dans le navigateur et préparer le checkpoint

- [x] Documenter les variables d’environnement dans `legacy/X_Studio/ENV_SETUP.md` sans valeurs secrètes
- [x] Ajouter une documentation pour fournir `.env` et `cookies.txt` hors du dépôt public
- [x] Ajouter un emplacement indicateur pour `__pycache__` sans bytecode temporaire
- [x] Vérifier le build et sauvegarder cette version sûre

- [x] Retirer le bouton de redirection vers YouTube de la page Accueil
- [x] Supprimer les liens YouTube visibles dans les résultats tout en conservant le téléchargement interne

- [x] Remplacer le clic des cartes vidéo par une lecture intégrée sans redirection YouTube
- [x] Faire lancer directement les morceaux locaux dans la page Play
- [x] Ajouter un bouton interne Télécharger MP3
- [x] Ajouter un bouton interne Télécharger vidéo
- [x] Tester les actions et sauvegarder la version corrigée

- [x] Recevoir le vrai `cookies.txt` par un canal privé
- [x] Configurer yt-dlp pour utiliser les cookies sans les exposer dans le dépôt
- [x] Tester un téléchargement MP3 ou vidéo avec les cookies privés
- [x] Vérifier qu’aucun cookie n’apparaît dans les logs ou la réponse utilisateur

- [x] Tester réellement `/api/xstudio/download` avec le secret cookies privé
- [x] Contrôler les réponses et logs backend pour confirmer l’absence du contenu cookies

- [x] Diagnostiquer l’échec cookies sur la vidéo Svx6-9HLEgQ sans exposer le contenu privé
- [x] Renforcer l’authentification yt-dlp avec l’import Cookies de la nouvelle application
- [x] Exposer la progression réelle du téléchargement côté backend
- [x] Ajouter notification, pourcentage et état final dans l’interface
- [x] Tester le flux et sauvegarder la correction

- [x] Remplacer le secret cookies privé par l’import du nouvel export complet reçu
- [x] Tester yt-dlp sur la vidéo bloquée avec le nouvel export
- [x] Vérifier la progression SSE et l’état final avec le nouvel export

- [x] Charger le contenu cookies complet directement depuis la page Cookies
- [x] Valider la structure et les cookies de session côté backend

- [x] Ajouter un bouton Cookies dans le menu latéral
- [x] Créer la page Cookies avec un bouton Importer
- [x] Lire le fichier cookies.txt localement sans l’envoyer au serveur
- [x] Valider le format Netscape et la présence de cookies de session
- [x] Vérifier les états valide, incomplet et fichier invalide dans le code et le build

- [x] Ajouter un test unitaire de la logique de validation du fichier cookies
- [x] Vérifier les états valide, incomplet et invalide par test automatisé et build

- [x] Vérifier le flux de progression et la notification via SSE et interface
- [x] Sauvegarder un checkpoint après validation du téléchargement

- [x] Inspecter toutes les commandes yt-dlp de `legacy/X_Studio/app.py`
- [x] Retirer `player_client=android` de `app.py`
- [x] Ajouter `--cookies ~/cookies/cookies.txt` aux téléchargements audio et vidéo
- [x] Valider la syntaxe et redémarrer le serveur Flask ; le fichier cookies local reste à fournir dans `~/cookies/cookies.txt`

- [x] Diagnostiquer l’arrêt yt-dlp au moment de l’écriture du fichier
- [x] Vérifier le dossier de sortie, les permissions et les noms de fichiers
- [x] Corriger la gestion de fin de processus et d’écriture MP3
- [x] Tester un téléchargement complet jusqu’à l’état terminé

- [x] Vérifier explicitement les permissions d’écriture de `legacy/X_Studio/downloads`
- [x] Confirmer la création effective d’un MP3 avec les cookies importés dans la nouvelle application

- [x] Ajouter un endpoint sécurisé d’import cookies dans la nouvelle version
- [x] Valider le fichier importé côté serveur sans l’exposer dans les réponses
- [x] Utiliser le cookie importé pour les téléchargements backend
- [x] Connecter le bouton Importer de la page Cookies à l’endpoint
- [x] Tester l’import depuis l’interface et un téléchargement complet

- [x] Diagnostiquer le nouveau téléchargement interrompu à 1 % après import Cookies
- [x] Corriger la cause de l’erreur habituelle et préserver la progression SSE avec persistance chiffrée inter-instances
- [x] Retester un téléchargement complet depuis l’interface

- [x] Supprimer la dépendance aux cookies dans le téléchargement public
- [x] Désactiver l’import et le stockage des cookies dans le parcours principal
- [x] Ajouter des tentatives publiques yt-dlp et des messages d’erreur compréhensibles
- [x] Tester un téléchargement public et la progression SSE
- [x] Publier la version sans cookies

- [x] Reproduire le clic de téléchargement et vérifier la présence réelle du fichier final
- [x] Corriger la livraison du fichier au navigateur après l’état terminé
- [x] Afficher une erreur uniquement si le fichier est réellement indisponible
- [x] Retester le téléchargement depuis l’interface publiée avant tout nouveau checkpoint

- [x] Vérifier la réponse finale de téléchargement et l’URL du fichier
- [x] Corriger la livraison réelle du fichier au navigateur
- [x] Tester le fichier audio fraîchement généré avec Content-Type audio/mpeg, taille et signature MP3
- [x] Ne publier aucune nouvelle version avant validation réelle du fichier

- [x] Rendre la route de récupération indépendante de la mémoire de tâche d’une instance
- [x] Autoriser la livraison sécurisée d’un fichier déjà stocké via sa clé de stockage
- [x] Retester le téléchargement sur le domaine publié après bascule d’instance

- [x] Remplacer la clé de stockage brute par un jeton de téléchargement signé
- [x] Publier la correction autoscale avec le jeton signé
- [x] Retester le téléchargement sur le domaine publié après cette publication

- [x] Vérifier que le domaine permanent reste xstudioapp-adphec9v.manus.space
- [x] Vérifier le bouton d’installation de l’application Web/PWA
- [x] Préparer un fichier ZIP de la nouvelle version sans secrets ni fichiers temporaires
- [x] Publier un checkpoint final et remettre le lien permanent ainsi que le fichier ZIP

- [x] Tester le bouton INSTALLER L’APPLICATION sur le domaine publié
- [x] Vérifier le manifeste et la configuration PWA servie par la version publiée
