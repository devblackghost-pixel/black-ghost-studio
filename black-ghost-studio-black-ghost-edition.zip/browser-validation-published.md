
# Validation domaine publié

Sur `https://xstudioapp-adphec9v.manus.space`, le bouton MP3 a été déclenché depuis l’interface. La notification a affiché 0 %, puis les tentatives publiques 1/3 et 2/3, 99 %, et enfin « MP3 prêt » à 100 %. Une vérification complémentaire est nécessaire pour confirmer que le lien RÉCUPÉRER LE FICHIER est rendu et que l’entrée apparaît dans l’historique du navigateur publié.

## Second test publié

Après rechargement avec un paramètre de cache renouvelé, le bouton MP3 du domaine publié affiche « Préparation du téléchargement MP3 », puis « Tentative publique 2/3 — 1 % ». La tâche est encore en cours au moment de cette capture ; il faut attendre l’état terminal avant de conclure.

## Validation finale avec jeton signé

Sur `https://xstudioapp-adphec9v.manus.space/?version=c3d31f46`, le bouton MP3 a terminé à 100 % et l’interface a affiché « RÉCUPÉRER LE FICHIER ». Après clic, l’historique Chrome contient une nouvelle entrée `Rick Astley - Never Gonna Give You Up (Official Video) (4K Remaster) (2).mp3` provenant de `https://xstudioapp-adphec9v.manus.space`. Cette preuve confirme que le lien signé est déployé et que le navigateur reçoit réellement le fichier sur le domaine publié.
