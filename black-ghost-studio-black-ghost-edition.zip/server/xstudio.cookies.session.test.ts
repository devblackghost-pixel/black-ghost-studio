import { describe, expect, it } from "vitest";

describe("YOUTUBE_COOKIES_B64 session export", () => {
  it("contains a Netscape export with session cookie names", () => {
    const encoded = process.env.YOUTUBE_COOKIES_B64;
    expect(encoded).toBeTruthy();
    const contents = Buffer.from(encoded || "", "base64").toString("utf8");
    expect(contents).toContain("# Netscape HTTP Cookie File");
    expect(contents).toContain("\tSID\t");
    expect(contents).toContain("\tSAPISID\t");
    expect(contents).toContain("__Secure-1PSID\t");
  });
});
