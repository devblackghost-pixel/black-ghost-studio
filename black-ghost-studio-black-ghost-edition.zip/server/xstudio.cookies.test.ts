import { describe, expect, it } from "vitest";

describe("X Studio YouTube cookies secret", () => {
  it("contains a valid Netscape cookies payload", () => {
    const encoded = process.env.YOUTUBE_COOKIES_B64;
    expect(encoded, "YOUTUBE_COOKIES_B64 must be configured").toBeTruthy();
    const decoded = Buffer.from(encoded || "", "base64").toString("utf8");
    expect(decoded).toContain("# Netscape HTTP Cookie File");
    expect(decoded).toContain(".youtube.com");
  });
});
