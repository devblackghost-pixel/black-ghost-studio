import { Router, type Request, type Response } from "express";
import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import { randomUUID, createHmac, timingSafeEqual } from "node:crypto";
import { spawn } from "node:child_process";
import { Readable } from "node:stream";
import { storagePut, storageGetSignedUrl } from "./storage";
import express from "express";

const router = Router();

const TRENDING_IDS = [
  "dQw4w9WgXcQ",
  "kJQP7kiw5Fk",
  "fJ9rUzIMcZQ",
  "YQHsXMglC9A",
  "RgKAFK5djSk",
  "CevxZvSJLk8",
  "OPf0YbXqDm0",
  "JGwWNGJdvx8",
  "hT_nvWreIhg",
  "nlcIKh6sBtc",
];

const library = [
  { id: "headlights", name: "Alok, Alan Walker - Headlights (Lyrics) ft. KIDDO.mp3", title: "Headlights", artist: "Alok, Alan Walker · KIDDO", url: "/manus-storage/headlights_3ded43a2.mp3", size: 4.67 },
  { id: "seiyu", name: "NEGRITO SENPAI - SEIYU (AMV ANIME MIX).mp3", title: "SEIYU", artist: "NEGRITO SENPAI", url: "/manus-storage/seiyu_6b7de9bf.mp3", size: 5.06 },
  { id: "never-gonna-give-you-up", name: "Rick Astley - Never Gonna Give You Up (Official Video) (4K Remaster) [dQw4w9WgXcQ].mp3", title: "Never Gonna Give You Up", artist: "Rick Astley", url: "/manus-storage/never-gonna-give-you-up_464f74bf.mp3", size: 6.72 },
  { id: "moonlight", name: "XXXTENTACION - MOONLIGHT (OFFICIAL MUSIC VIDEO).mp3", title: "MOONLIGHT", artist: "XXXTENTACION", url: "/manus-storage/moonlight_522e1c33.mp3", size: 4.39 },
  { id: "mortals", name: "Mortals Funk Remix - Solo Leveling.mp3", title: "Mortals Funk Remix", artist: "Solo Leveling · AMV", url: "/manus-storage/mortals_586d9590.mp3", size: 4.8 },
];

const removed = new Set<string>();

function video(id: string, title = "Vidéo tendance", channel = "YouTube") {
  return { id, title, channel, duration: "", views: "", thumbnails: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`, url: `https://youtube.com/watch?v=${id}`, embed_url: `https://www.youtube.com/embed/${id}` };
}

async function searchYoutube(query: string, limit = 15) {
  const response = await fetch(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`, {
    headers: { "user-agent": "Mozilla/5.0 X Studio" },
  });
  const html = await response.text();
  const results: ReturnType<typeof video>[] = [];
  const pattern = /"videoId":"([^"]+)"/g;
  for (const item of Array.from(html.matchAll(pattern))) {
    const id = item[1];
    if (!id || results.some((entry) => entry.id === id)) continue;
    results.push(video(id, `Résultat YouTube pour ${query}`, "YouTube"));
    if (results.length >= limit) break;
  }
  return results;
}

router.get("/search", async (req: Request, res: Response) => {
  const query = String(req.query.q || "").trim();
  if (!query) return res.json({ results: [] });
  try {
    return res.json({ results: await searchYoutube(query) });
  } catch (error) {
    console.error("[X Studio] search failed", error);
    return res.status(502).json({ error: "La recherche YouTube est temporairement indisponible.", results: [] });
  }
});

router.get("/trending", (_req, res) => res.json({ results: TRENDING_IDS.map((id) => video(id)) }));
router.get("/suggestions", (req, res) => {
  const query = String(req.query.q || "").trim().toLowerCase();
  if (!query) return res.json({ suggestions: [] });
  return res.json({ suggestions: [`${query} music`, `${query} song`, `${query} video`, `${query} official`, `${query} remix`] });
});
router.get("/library", (_req, res) => res.json(library.filter((song) => !removed.has(song.id))));

router.delete("/library/:id", (req, res) => {
  const song = library.find((item) => item.id === req.params.id);
  if (!song) return res.status(404).json({ error: "Fichier non trouvé" });
  removed.add(song.id);
  return res.json({ status: "deleted", id: song.id });
});

type DownloadTask = {
  id: string;
  format: "mp3" | "video";
  progress: number;
  status: "queued" | "downloading" | "completed" | "error";
  message: string;
  filename?: string;
  url?: string;
  key?: string;
  fileToken?: string;
};

const downloadTasks = new Map<string, DownloadTask>();

function downloadTokenSecret() {
  return process.env.JWT_SECRET || "xstudio-download-secret";
}

function createDownloadToken(taskId: string, key: string, format: "mp3" | "video", filename: string) {
  const payload = Buffer.from(JSON.stringify({ taskId, key, format, filename })).toString("base64url");
  const signature = createHmac("sha256", downloadTokenSecret()).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

function readDownloadToken(token: string) {
  try {
    const [payload, signature] = token.split(".");
    if (!payload || !signature) return null;
    const expected = createHmac("sha256", downloadTokenSecret()).update(payload).digest("base64url");
    if (signature.length !== expected.length || !timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return null;
    const parsed = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    if (!parsed.taskId || !parsed.key || !parsed.key.startsWith("downloads/") || parsed.key.includes("..")) return null;
    return parsed as { taskId: string; key: string; format: "mp3" | "video"; filename: string };
  } catch {
    return null;
  }
}

function redactDownloadError(value: string) {
  if (/HTTP Error 400|Sign in to confirm|not a bot|HTTP Error 403|HTTP Error 429/i.test(value)) {
    return "YouTube bloque actuellement cette source publique. Essayez une autre vidéo ou importez un fichier dont vous détenez les droits dans votre bibliothèque.";
  }
  return value
    .replace(/(cookies?)([=:\s]+)[^\s]+/gi, "$1 [redacted]")
    .replace(/(__Secure-[A-Za-z0-9_-]+|VISITOR_[A-Za-z0-9_-]+|SOCS|YSC)\s+[^\s]+/g, "$1 [redacted]")
    .slice(-500);
}

function updateDownload(taskId: string, patch: Partial<DownloadTask>) {
  const current = downloadTasks.get(taskId);
  if (!current) return;
  downloadTasks.set(taskId, { ...current, ...patch });
}

function parseProgress(text: string) {
  const match = text.match(/(\d+(?:\.\d+)?)%/);
  return match ? Math.max(0, Math.min(99, Math.round(Number(match[1])))) : null;
}

async function runDownload(taskId: string, url: string, format: "mp3" | "video", quality: string) {
  const task = downloadTasks.get(taskId);
  if (!task) return;
  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "xstudio-"));
  const output = path.join(tempDir, "%(title)s.%(ext)s");
  const isVideo = format === "video";
  try {
    updateDownload(taskId, { status: "downloading", progress: 1, message: "Connexion à la source…" });
    const args = isVideo
      ? ["--ignore-config", "--newline", "--no-playlist", "-f", quality === "best" ? "bv*+ba/b" : "bv*[height<=720]+ba/b[height<=720]", "--merge-output-format", "mp4", "--no-check-certificate", "-o", output, url]
      : ["--ignore-config", "--newline", "--no-playlist", "--extract-audio", "--audio-format", "mp3", "--audio-quality", "0", "--no-check-certificate", "-o", output, url];
    if (quality === "best") args.splice(0, 0, "--remote-components", "ejs:github", "--js-runtimes", "node");
    const strategies = [
      [],
      ["--extractor-args", "youtube:player_client=web_safari"],
      ["--extractor-args", "youtube:player_client=tv_embedded"],
    ];
    let lastError = "";
    for (let index = 0; index < strategies.length; index += 1) {
      const attemptArgs = [...args, ...strategies[index]];
      updateDownload(taskId, { status: "downloading", progress: 1, message: `Tentative publique ${index + 1}/${strategies.length}…` });
      try {
        await new Promise<void>((resolve, reject) => {
          const child = spawn("yt-dlp", attemptArgs, { cwd: tempDir });
          let stderr = "";
          const onOutput = (chunk: Buffer) => {
            const progress = parseProgress(chunk.toString());
            if (progress !== null) updateDownload(taskId, { progress, message: `Téléchargement en cours… ${progress}%` });
          };
          child.stdout.on("data", onOutput);
          child.stderr.on("data", (chunk) => { stderr += chunk.toString(); onOutput(chunk); });
          child.on("error", reject);
          child.on("close", (code) => code === 0 ? resolve() : reject(new Error(stderr || "yt-dlp a refusé la source publique")));
        });
        lastError = "";
        break;
      } catch (error) {
        lastError = error instanceof Error ? error.message : "Échec de la tentative publique";
        for (const file of await fs.readdir(tempDir)) await fs.rm(path.join(tempDir, file), { force: true });
      }
    }
    if (lastError) throw new Error(lastError);
    const files = (await fs.readdir(tempDir)).filter((file) => isVideo ? file.endsWith(".mp4") : file.endsWith(".mp3"));
    if (!files[0]) throw new Error(`Aucun fichier ${isVideo ? "vidéo" : "MP3"} généré.`);
    const fileName = files[0].replace(/[^a-zA-Z0-9._-]/g, "_");
    const bytes = await fs.readFile(path.join(tempDir, files[0]));
    const stored = await storagePut(`downloads/${randomUUID()}-${fileName}`, bytes, isVideo ? "video/mp4" : "audio/mpeg");
    updateDownload(taskId, { status: "completed", progress: 100, message: `${isVideo ? "Vidéo" : "MP3"} prêt`, filename: files[0], url: stored.url, key: stored.key, fileToken: createDownloadToken(taskId, stored.key, format, files[0]) });
  } catch (error) {
    const message = redactDownloadError(error instanceof Error ? error.message : "Téléchargement impossible");
    console.error("[X Studio] download failed:", message);
    updateDownload(taskId, { status: "error", message });
  } finally {
    await fs.rm(tempDir, { recursive: true, force: true });
  }
}

router.get("/download-file/:taskId", async (req, res) => {
  const task = downloadTasks.get(req.params.taskId);
  const token = typeof req.query.token === "string" ? readDownloadToken(req.query.token) : null;
  if (!token || token.taskId !== req.params.taskId) return res.status(404).json({ error: "Jeton de téléchargement invalide" });
  const key = token.key;
  const format = token.format;
  const requestedName = token.filename;
  try {
    const signedUrl = await storageGetSignedUrl(key);
    const upstream = await fetch(signedUrl);
    if (!upstream.ok || !upstream.body) return res.status(502).json({ error: "Fichier de stockage indisponible" });
    const fallbackName = format === "mp3" ? "x-studio.mp3" : "x-studio.mp4";
    const filename = (task?.filename || requestedName || fallbackName).replace(/[\r\n"\\]/g, "_");
    res.setHeader("Content-Type", format === "mp3" ? "audio/mpeg" : "video/mp4");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader("Cache-Control", "private, no-store");
    Readable.fromWeb(upstream.body as any).pipe(res);
  } catch (error) {
    console.error("[X Studio] file delivery failed:", error instanceof Error ? error.message : "storage error");
    if (!res.headersSent) res.status(502).json({ error: "Impossible de récupérer le fichier" });
  }
});

router.get("/download-progress/:taskId", (req, res) => {
  const task = downloadTasks.get(req.params.taskId);
  if (!task) return res.status(404).json({ error: "Tâche introuvable" });
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  const send = () => res.write(`data: ${JSON.stringify(downloadTasks.get(req.params.taskId))}\n\n`);
  send();
  const interval = setInterval(() => {
    send();
    const current = downloadTasks.get(req.params.taskId);
    if (current?.status === "completed" || current?.status === "error") clearInterval(interval);
  }, 500);
  req.on("close", () => clearInterval(interval));
});

router.post("/download", (req, res) => {
  const { url, format = "mp3", quality = "best" } = req.body || {};
  if (!url) return res.status(400).json({ error: "URL requise" });
  if (format !== "mp3" && format !== "video") return res.status(400).json({ error: "Format non pris en charge." });
  const taskId = randomUUID();
  downloadTasks.set(taskId, { id: taskId, format, progress: 0, status: "queued", message: "Téléchargement placé dans la file" });
  void runDownload(taskId, String(url), format, String(quality));
  return res.status(202).json({ status: "queued", taskId, format });
});

export function registerXStudioRoutes(app: import("express").Express) {
  app.use("/api/xstudio", router);
}
