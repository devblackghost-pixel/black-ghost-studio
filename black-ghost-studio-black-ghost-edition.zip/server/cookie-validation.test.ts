import { describe, expect, it } from "vitest";
import { validateCookieContents } from "../client/src/lib/cookieValidation";

const header = "# Netscape HTTP Cookie File\n";

describe("cookie validation UI logic", () => {
  it("returns valid, incomplete and invalid states", () => {
    expect(validateCookieContents(`${header}.youtube.com\tTRUE\t/\tTRUE\t0\tSID\tvalue\n.youtube.com\tTRUE\t/\tTRUE\t0\tSAPISID\tvalue\n`).status).toBe("valid");
    expect(validateCookieContents(`${header}.youtube.com\tTRUE\t/\tTRUE\t0\tPREF\tvalue\n`).status).toBe("incomplete");
    expect(validateCookieContents("not a cookie export").status).toBe("invalid");
  });
});
