
# Validation PWA

Le domaine permanent `https://xstudioapp-adphec9v.manus.space` sert le manifeste `__manus/pwa/manifest.webmanifest`. Il contient `name: X Studio`, `short_name: X Studio`, `start_url: /`, `scope: /` et `display: standalone`. La configuration d’installation Web/PWA est donc présente ; l’interface ajoute maintenant un bouton explicite qui utilise `beforeinstallprompt` lorsqu’il est disponible et affiche une instruction navigateur sinon.

## Validation sur le domaine permanent

Après republication et nettoyage du cache, `https://xstudioapp-adphec9v.manus.space` affiche bien le bouton **INSTALLER L’APPLICATION**. Le clic a été déclenché dans le navigateur ; sur cet environnement, aucune invite native n’a été affichée, ce qui correspond au comportement prévu du fallback navigateur. Le bouton reste utilisable sur les navigateurs compatibles `beforeinstallprompt`, et le manifeste PWA est servi par le domaine.
