# Vérification lecture intégrée

Le 19 août 2026, la prévisualisation X Studio est restée sur l’URL WebDev après le clic sur la carte vidéo. Le lecteur intégré `youtube-nocookie.com/embed/...` est apparu dans la page avec le titre « Lecture vidéo intégrée » et un bouton de fermeture. Les cartes affichent désormais deux actions internes : « MP3 » et « VIDÉO ». Aucun changement de navigation vers une page YouTube n’a été observé. Le build TypeScript, les tests Vitest et le build production ont réussi après ces changements.
